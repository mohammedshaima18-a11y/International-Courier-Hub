@echo off
set JAVA_HOME=C:\Program Files\Java\jdk-17
echo Building and launching International Courier Hub...
call mvn clean javafx:run
pause
